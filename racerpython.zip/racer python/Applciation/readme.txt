To run the application, simply run "python game_gen.py <path_to_game_gen.racer>

The application will generate a level with 10 rooms and display the rooms with their neighbours, room type and contents.
