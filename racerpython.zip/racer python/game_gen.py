\begin{verbatim}
from pracer.racer_client import RacerClient
import random 
import sys

def add_room_south(current_room, added_room, racer_client):
    racer_client.related_m(added_room["name"], current_room["name"], 'is_south_of')
    current_room["s"] = added_room["name"]
    added_room["n"] = current_room["name"]

def add_room_north(current_room, added_room, racer_client):
    racer_client.related_m(added_room["name"], current_room["name"], 'is_north_of')
    current_room["n"] = added_room["name"]
    added_room["s"] = current_room["name"]

def add_room_east(current_room, added_room, racer_client):
    racer_client.related_m(added_room["name"], current_room["name"], 'is_east_of')
    current_room["e"] = added_room["name"]
    added_room["w"] = current_room["name"]

def add_room_west(current_room, added_room, racer_client):
    racer_client.related_m(added_room["name"], current_room["name"], 'is_west_of')
    current_room["w"] = added_room["name"]
    added_room["e"] = current_room["name"]

def add_room_types(available_types, rooms, racer_client):
    for room in rooms:
        random_var = random.randint(0, len(available_types) - 1)
        new_type = available_types.pop(random_var)
        room['type'] = new_type
        racer_client.related_m(room['name'], new_type, 'has_type')

def add_room(available_spots, room_nr, rooms, racer_client):
    direction = random.randint(0,len(available_spots) - 1)
    new_dir = available_spots.pop(direction)

    new_room = {}
    new_room['name'] = 'room_' + str(room_nr)
    rooms.append(new_room)
    racer_client.instance_m(new_room['name'], 'room')

    if new_dir[0] == 's':
        add_room_south(new_dir[1], new_room, racer_client)
        available_spots.append(['s', new_room])
        available_spots.append(['e', new_room])
        available_spots.append(['w', new_room])

    if new_dir[0] == 'n':
        add_room_north(new_dir[1], new_room, racer_client)
        available_spots.append(['n', new_room])
        available_spots.append(['e', new_room])
        available_spots.append(['w', new_room])

    if new_dir[0] == 'w':
        add_room_west(new_dir[1], new_room, racer_client)
        available_spots.append(['s', new_room])
        available_spots.append(['n', new_room])
        available_spots.append(['w', new_room])

    if new_dir[0] == 'e':
        add_room_east(new_dir[1], new_room, racer_client)
        available_spots.append(['s', new_room])
        available_spots.append(['e', new_room])
        available_spots.append(['n', new_room])

def generate_level(racer_client):

    rooms = [];
    nr_of_rooms = 1

    room1 = {}
    room1['name'] = 'room_1'
    rooms.append(room1)

    racer_client.instance_m(room1['name'], 'room')

    available_spots = []
    available_spots.append(['s', room1])
    available_spots.append(['n', room1])
    available_spots.append(['e', room1])
    available_spots.append(['w', room1])

    while nr_of_rooms < 10:
        nr_of_rooms += 1
        add_room(available_spots, nr_of_rooms, rooms, racer_client)

    available_types = []

    #add 6 normal rooms
    for i in range(6):
        available_types.append('normal_room')

    available_types.append('starting_room')
    available_types.append('treasure_room')
    available_types.append('shop_room')
    available_types.append('boss_room')

    add_room_types(available_types, rooms, racer_client)

    racer_client.run_all_rules()

    fill_room_conents(rooms, racer_client)

    for room in rooms:
        print(room)

def parse_result_filler(input):
    result = input.strip("\"() \n")
    return result.split("\"(")[1].split(" ")

def parse_result_retrieve(input):
    result = input.strip("\"() \n")
    result = result.split('((?X ')
    new_result = []
    for entry in result[1:]:
        entry = entry.strip(")) ")
        new_result.append(entry)
    return new_result

def fill_room_conents(rooms, racer_client):
    for room in rooms:
        result = racer_client.retrieve_individual_fillers(room['name'], 'contains')

        #parse result
        available_content_types = parse_result_filler(result)

        random_var = random.randint(0, len(available_content_types) - 1)
        contents_type = available_content_types[random_var]

        result = racer_client.retrieve_m('(?x)', '(?x ' + contents_type + ')')
        available_contents = parse_result_retrieve(result)
        random_var = random.randint(0, len(available_contents) - 1)
        contents = available_contents[random_var]
        room['contents'] = contents
        room['contents_type'] = contents_type


def main():
    if len(sys.argv) < 2:
        print("Please specify the path for the game.racer file")
        exit()

    racer_file_path = sys.argv[1]

    racer_client = RacerClient('127.0.0.1', 8088)
    racer_client.connect()
    racer_client.full_reset()
    result = racer_client.racer_read_file_('\"' + racer_file_path + '\"')
    result = racer_client.all_atomic_concepts_()

    #generate level
    generate_level(racer_client)

    racer_client.disconnect()

if __name__ == '__main__':
    main()
\end{verbatim}
